/**
 * CS 2110 - Spring 2016 - Homework #10
 *
 * @author Stephanie Remy
 *
 * deque.c: Complete the functions!
 */

#include <stdlib.h>
#include <stdio.h>
#include "deque.h"

/* The node struct. Has a prev pointer, next pointer, and data. */
/* DO NOT DEFINE ANYTHING OTHER THAN WHAT'S GIVEN OR YOU WILL GET A ZERO */
/* Design consideration: Only this file should know about nodes */
/* Only this file should be manipulating nodes */
/* DO NOT TOUCH THIS DECLARATION, DO NOT PUT IT IN OTHER FILES */
typedef struct dnode
{
    struct dnode* prev; /* Pointer to previous node */
    struct dnode* next; /* Pointer to next node */
    void* data; /* User data */
} node;

/* Do not create any global variables here. Your deque library should obviously
 * work for multiple concurrent deques */

// This function is declared as static since you should only be calling this
// function from inside this file.
static node* create_node(void* data);

/** create_node
  *
  * Helper function that creates a node by allocating memory for it on the heap.
  * Be sure to set its pointers to NULL.
  *
  * @param data a void pointer to data the user wants to store in the deque
  * @return a node
  */
static node* create_node(void* data)
{
    node* theNode = malloc(sizeof(node));
	//checks to see if malloc returned null
	if(theNode == NULL){
		free(theNode);
		return NULL;	
	}else{
		//sets data and pointers to null
		theNode->data = data;
		theNode->prev = NULL;
		theNode->next = NULL;
		return theNode;
	} 
}

/** create_deque
  *
  * Creates a deque by allocating memory for it on the heap.
  * Be sure to initialize size to zero and head/tail to NULL.
  *
  * @return an empty deque
  */
deque* create_deque(void)
{
    deque* theDeque = malloc(sizeof(deque));
	//checks to see if malloc returned null
	if(theDeque == NULL){
		return NULL;
	}else{
		//sets size to zero and head/tail to NULL
		theDeque->head = NULL;
		theDeque->tail = NULL;
		theDeque->size = 0;
		return theDeque;
	}
}

/** push_front
  *
  * Adds the data to the front of the deque.
  *
  * @param d a pointer to the deque structure.
  * @param data pointer to data the user wants to store in the deque.
  */
void push_front(deque *d, void *data)
{
	//create a new node with the data
	node* newNode = create_node(data);
	//checks if the newNode is null or not. Only adds it if not null
	if(newNode != NULL && d != NULL){
		//checks to see if there is nothing on the list
		if(!d->size) {
			//sets pointers
			newNode->next = NULL;
			newNode->prev = NULL;
			//change head and tail
			d->head = newNode;
			d->tail = newNode;
		}else{
		//if there is at least one item on the list
			node* currHead = d->head;
			//sets pointers
			newNode->next = currHead;
			newNode->prev = NULL;
			currHead->prev = newNode;
			//change to new head
			d->head = newNode;
		}
		d->size++;
	}
}

/** push_back
  *
  * Adds the data to the back of the deque.
  *
  * @param d a pointer to the deque structure.
  * @param data pointer to data the user wants to store in the deque.
  */
void push_back(deque *d, void *data)
{
	
	//create a new node with the data
	node* newNode = create_node(data);
	//checks if the newNode is null or not. Only adds it if not null
	if(newNode != NULL && d != NULL){
		//checks to see if there is nothing on the list
		if(!d->size) {
			//sets pointers
			newNode->next = NULL;
			newNode->prev = NULL;
			//change head and tail
			d->head = newNode;
			d->tail = newNode;
		}else{
		//if there is at least one item on the list
			node* currTail = d->tail;
			//sets pointers
			newNode->next = NULL;
			newNode->prev = currTail;
			currTail->next = newNode;
			//change to new tail
			d->tail = newNode;
		}
		d->size++;
	}
}

/** front
  *
  * Gets the data at the front of the deque
  * If the deque is empty return NULL.
  *
  * @param d a pointer to the deque
  * @return The data at the first node in the deque or NULL.
  */
void *front(deque *d)
{
	if(d == NULL) return NULL;
	//if current list has something on the list
	if(d->size){
		return (d->head->data);
	}else{
		//list is empty so return null
		return NULL;
	}
}

/** back
  *
  * Gets the data at the "end" of the deque
  * If the deque is empty return NULL.
  *
  * @param d a pointer to the deque structure
  * @return The data at the last node in the deque or NULL.
  */
void *back(deque *d)
{
	if(d == NULL) return NULL;
    //if current list has something on the list
	if(d->size){
		return (d->tail->data);
	}else{
		//list is empty so return null
		return NULL;
	}
}

/** get
  *
  * Gets the data at the specified index in the deque
  *
  * @param d a pointer to the deque structure
  * @param index 0-based, starting from the head.
  * @return The data from the specified index in the deque or NULL if index is
  *         out of range of the deque.
  */
void *get(deque *d, int index)
{
	if(d == NULL) return NULL;
	if(d->size == 0) return NULL;
	if(index >= d->size) return NULL;
	if(index < 0) return NULL;
	//start at the front
	node* curr = d->head;
	for(int i = 0; i < index; i++) {
		curr = curr->next;
	}
	return curr->data;
}

/** contains
  *
  * Traverses the deque, trying to see if the deque contains some data.
  * Since non-NULL values are considered true, this can be used like a boolean
  *
  * The "data" parameter may not necessarily point to the same address as the
  * equal data you are returning from this function, it's just data which the
  * eq_func says is equal. For instance, if you have a deque of person structs:
  *   (Andrew, 26), (Nick, 24), (Collin, 23), (Marie, 23)
  * And you want to return any person whose age is 22, you could create a new
  * person struct (<NULL>, 24) with an eq_func that returns age == 24 and pass
  * that into this function as "data". contains() would then return (Nick, 24)
  *
  * If there are multiple pieces of data in the deque which are equal to the
  * "data" parameter, return any one of them.
  *
  * @param d a pointer to the deque structure
  * @param data The data, to see if it exists in the deque
  * @param eq_func A function written by the user that will tell if two pieces
  *                of data are equal. Returns 0 if equal, something else
  *                otherwise. Imagine subtracting two numbers.
  * @return The data contained in the deque, or NULL if it doesn't exist
  */
void *contains(deque *d, void *data, deque_eq eq_func) {
	if(d == NULL) return NULL;
	//start at the front
	node* curr = d->head;
	int size = d->size;
	for(int i = 0; i < size; i++) {
		if(!eq_func(curr->data, data)) return curr->data;
		curr = curr->next;
	}
	return NULL;
}

/** pop_front
  *
  * Removes the node at the front of the deque, and returns its data to the user
  *
  * @param d a pointer to the deque.
  * @return The data in the first node, or NULL if the deque is NULL or empty
  */
void *pop_front(deque *d)
{
	if(d == NULL) return NULL;
	//if deque is empty return -1
	if(!d->size) return NULL;
	//get the current head
	node* currHead = d->head;
	//if only one node in deque
	if(d->size == 1) {
		d->head = NULL;
		d->tail = NULL;
	} else {
		//if more than one node in deque fix pointers and new head
		node* headNext = currHead->next;
		d->head = headNext;
		headNext->prev = NULL;
	}
	d->size--;
	void* data = currHead->data;
	free(currHead);
	return data;
}

/** pop_back
  *
  * Removes the node at the end of the deque, and returns its data to the user
  *
  * @param d a pointer to the deque.
  * @return The data in the first node, or NULL if the deque is NULL or empty
  */
void *pop_back(deque *d)
{
	if(d == NULL) return NULL;
	if(!d->size) return NULL;
	//get the current head
	node* currTail = d->tail;
	//if only one node in list
	if(d->size == 1) {
		d->head = NULL;
		d->tail = NULL;
	} else {
		//if more than one node in list fix pointers and new head
		node* tailPrev = currTail->prev;
		d->tail = tailPrev;
		tailPrev->next = NULL;
	}
	d->size--;
	void* data = currTail->data;
	free(currTail);
	return data;
}

/** copy_deque
  *
  * Create a new deque structure, new nodes, and new copies of the data by using
  * the copy function. Its implementation for any test structure must copy
  * EVERYTHING!
  *
  * @param d A pointer to the deque structure to make a copy of
  * @param copy_func A function pointer to a function that makes a copy of the
  *                  data that's being used in this deque, allocating space for
  *                  every part of that data on the heap. This is some function
  *                  you must write yourself for testing, tailored specifically
  *                  to whatever context you're using the deque for in your test
  * @return The deque structure created by copying the old one, or NULL if the
  *         structure passed in is NULL.
  */
deque* copy_deque(deque *d, deque_copy copy_func)
{
	if(d == NULL) return NULL;
	//the copy deque that is going to be returned
	deque* cDdeque = create_deque();
	//if given empty deque return empty list
	if(!d->size) return cDdeque;
	
	//start at the front
	node* curr = d->head;
	//for every item in d
	int size = d->size;
	int isHead = 1;
	for(int i = 0; i < size; i++) {
		if(isHead){
			push_front(cDdeque, copy_func(curr->data));
		} else {
			push_back(cDdeque, copy_func(curr->data));
		}
		isHead = 0;
		curr = curr->next;
	}
	return cDdeque;
}

/** size
  *
  * Gets the size of the deque
  *
  * @param d a pointer to the deque structure
  * @return The size of the deque
  */
int size(deque *d)
{
    if(d == NULL) return 0;
    return d->size;
}

/** remove_if
  *
  * Removes all nodes whose data when passed into the predicate function returns
  * true
  *
  * @param d a pointer to the deque structure
  * @param pred_func a pointer to a function that when it returns true, it
  *                  should remove the element from the deque.
  * @param free_func a pointer to a function that is responsible for freeing the
  *                  node's data
  * @return the number of nodes that were removed.
  */
int remove_if(deque *d, deque_pred pred_func, deque_op free_func)
{
    /// @todo Implement changing the return value!
    /// @note remember to also free all nodes you remove.
    /// @note be sure to call pred_func on the NODES DATA to check if the node
    ///       needs to be removed.
    /// @note free_func is a function that is responsible for freeing the node's
    ///       data only.
	//create number to be returned
	int removed = 0;
	if(d == NULL) return 0;
	//check if list is empty
	if(!d->size) return removed;

	//start at the front need next and prev for changing of pointers
	node* curr = d->head;
	node* next;
	int theHead = 1;
	int size = d->size;
	for(int i = 0; i < size; i++) {
		//checks if needs to be removed
		if(pred_func(curr->data)){
			//change to new head
			if(theHead){
				if (d->size > 1){
					d->head = d->head->next;
					d->head->prev = NULL;
				} else{
					d->head = NULL;
					d->tail = NULL;
				}
			} else {
				curr->prev->next = curr->next;
				next = curr->next;
				if(next != NULL){
					next->prev = curr->prev;
				}else{
					d->tail = curr->prev;
				}
			}
			next = curr->next;
			free_func(curr->data);
			free(curr);
			curr = next;
			removed++;
			d->size--;
		} else {
			theHead = 0;
			curr = curr->next;
		}
	}
	return removed;
}

/** is_empty
  *
  * Checks to see if the deque is empty.
  *
  * @param d a pointer to the deque structure
  * @return 1 if the deque is indeed empty, or 0 otherwise.
  */
int is_empty(deque *d)
{
	if(d == NULL) return 0;
	if(!d->size) {
		return 1;
	}else{
		return 0;
	}
}

/** empty_deque
  *
  * Empties the deque. After this is called, the deque should be empty.
  * This does not free the deque struct itself, just all nodes and data within.
  *
  * @param d a pointer to the deque structure
  * @param free_func function used to free the nodes' data.
  */
void empty_deque(deque *d, deque_op free_func)
{
	//empty only if there is something on deque
	if((d->size) > 0){
		node* curr = d->head;
		node* next = d->head->next;
		int size = d->size;
		for(int i = 0; i < size; i++){
			//go through deque and free every node
			free_func(curr->data);
			free(curr);
			//go to the next node
			curr = next;
			//dont want next to be null
			if(i < (size-1)) {
				next = curr->next;
			}
		}
		//reset everything in d
		d->head = NULL;
		d->tail = NULL;
		d->size = 0;
	}
}

/** traverse
  *
  * Traverses the deque, calling a function on each node's data.
  *
  * @param d a pointer to the deque structure
  * @param do_func a function that does something to each node's data.
  */
void traverse(deque *d, deque_op do_func)
{
	//start at the front
	node* curr = d->head;
	int size = d->size;
	for(int i = 0; i < size; i++) {
		do_func(curr->data);
		curr = curr->next;
	}
}
