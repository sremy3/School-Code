#include <stdlib.h>
#include <time.h>
#include "my_malloc.h"

int main() {
    /* do some testing */
	return 0;
}
