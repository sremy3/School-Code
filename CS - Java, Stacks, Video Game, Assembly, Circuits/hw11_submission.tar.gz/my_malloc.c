#include "my_malloc.h"

/* You *MUST* use this macro when calling my_sbrk to allocate the
 * appropriate size. Failure to do so may result in an incorrect
 * grading!
 */
/*STEPHANIE REMY*/
#define SBRK_SIZE 2048

/* Please use this value as your canary! */
#define CANARY 0x2110CAFE

/* If you want to use debugging printouts, it is HIGHLY recommended
 * to use this macro or something similar. If you produce output from
 * your code then you may receive a 20 point deduction. You have been
 * warned.
 */
#ifdef DEBUG
#define DEBUG_PRINT(x) printf x
#else
#define DEBUG_PRINT(x)
#endif


/* our freelist structure - this is where the current freelist of
 * blocks will be maintained. failure to maintain the list inside
 * of this structure will result in no credit, as the grader will
 * expect it to be maintained here.
 * Technically this should be declared static for the same reasons
 * as above, but DO NOT CHANGE the way this structure is declared
 * or it will break the autograder.
 */
metadata_t* freelist;
metadata_t* createBlock()
{
	/*GRAB HUGE BLOCK*/
	metadata_t* newBlock = my_sbrk(SBRK_SIZE);
	if(newBlock == NULL){
		return NULL;
	}
	newBlock-> block_size = SBRK_SIZE;
	newBlock-> request_size = 0;
	newBlock-> next = NULL;
	newBlock-> prev = NULL;
	return newBlock;
}
metadata_t* setCanaries(metadata_t* userBlock)
{
	int* secondCanary;
	int* firstCanary;
	char* blockForUser;
	blockForUser = (((char*) userBlock) +(sizeof(metadata_t) + sizeof(int)));
        
	/*currently blockforuser is pointing at the first canary*/
	
	firstCanary= (int*) (((char*)userBlock)+sizeof(metadata_t));
	*firstCanary = CANARY;	
	secondCanary = (int*) (((char*)userBlock)+ + sizeof(int) +sizeof(metadata_t) + userBlock->request_size);
	*secondCanary = CANARY;
	return (metadata_t*) blockForUser;
}

void* my_malloc(size_t size)
{
	/*create size of block with 2 canaries and metadata*/
	size_t sizeNeeded;
	sizeNeeded = size + sizeof(metadata_t) + 2*sizeof(int);
	/*check if they asked for an appropriate size or not*/
	if(((int)size <= 0) || (sizeNeeded > 2048)){
		ERRNO = SINGLE_REQUEST_TOO_LARGE;
		return NULL;
	}else{
		ERRNO = NO_ERROR;
	}
	if(freelist == NULL){
		char* secondBlock;
		int i;
		metadata_t* blockBackOnFreelist;
		metadata_t* blockForUser;
		freelist = createBlock();
		if(freelist == NULL){
			ERRNO = OUT_OF_MEMORY;
			return NULL;
		}else{
			ERRNO = NO_ERROR;
		}
		secondBlock= (char*) freelist;
		for(i=0; i<sizeNeeded; i++){
			secondBlock++;
		}
		blockForUser = freelist;
		blockBackOnFreelist = (metadata_t*)secondBlock;
		blockForUser-> block_size = sizeNeeded;
		blockForUser-> request_size = size;	
		blockForUser-> next = NULL;
		blockForUser-> prev = NULL;
		blockBackOnFreelist-> block_size = (SBRK_SIZE - sizeNeeded);
		blockBackOnFreelist-> request_size = 0;
		blockBackOnFreelist-> next = NULL;
		blockBackOnFreelist-> prev = NULL;
		freelist = blockBackOnFreelist;
		blockForUser = setCanaries(blockForUser);
		return (void*) blockForUser;
	}else{
	/*check freelist if piece available*/
		metadata_t* curr;
		metadata_t* smallestPossibleBlock;
		size_t smallestPossibleBlockSize = 0;
		if(freelist->block_size > sizeNeeded){
			smallestPossibleBlock= freelist;
			smallestPossibleBlockSize= freelist->block_size;
		}
		curr = freelist;
		while(curr != NULL){
			size_t block_size = curr->block_size;
			if( block_size > sizeNeeded){
				if((char*)smallestPossibleBlockSize == NULL){
					
					smallestPossibleBlock = curr;
					smallestPossibleBlockSize = block_size;
				}else if(smallestPossibleBlockSize > block_size){
					
					smallestPossibleBlock = curr;
					smallestPossibleBlockSize = block_size;
				}
			}
			curr = curr->next;
		}
		/*fflush(stderr);*/
		if(smallestPossibleBlockSize == 0 || smallestPossibleBlockSize < sizeNeeded){
			/*otherwise create newBlock*/
			metadata_t* currHead;
			metadata_t* blockForUser;
			metadata_t* blockBackOnFreelist;
			metadata_t* newBlock;
			newBlock = createBlock();
			if(newBlock == NULL){
				ERRNO = OUT_OF_MEMORY;
				return NULL;
			}else{
				ERRNO = NO_ERROR;
			}
			if((sizeNeeded + sizeof(metadata_t*) + 2*sizeof(int)+ 1) < SBRK_SIZE){ 
			blockBackOnFreelist = (metadata_t *)(((char*) newBlock) +(size + sizeof(metadata_t) + 2*sizeof(int)));
			blockForUser = newBlock;
			
			blockForUser-> block_size = sizeNeeded;
			blockForUser-> request_size = size;
			blockForUser-> next = NULL;
			blockForUser-> prev = NULL;
			blockBackOnFreelist-> block_size = (SBRK_SIZE - sizeNeeded);
			blockBackOnFreelist-> request_size = 0;
			blockBackOnFreelist-> prev = NULL;
			/*put blockBackOnFreelist on freelist*/
			currHead = freelist;
			currHead->prev = blockBackOnFreelist;
			blockBackOnFreelist->next = currHead;
			freelist = blockBackOnFreelist;
			blockForUser = setCanaries(blockForUser);
			return (void*) blockForUser;
			}else{
				blockForUser = newBlock;
				blockForUser-> block_size = sizeNeeded;
				blockForUser-> request_size = size;
				blockForUser-> next = NULL;
				blockForUser-> prev = NULL;
				
				blockForUser = setCanaries(blockForUser);
				return (void*) blockForUser;
			}
		}else{
		
			/*use the smallestBlockSize
			//if when I cut it the remaining block is big enough to make another block*/
			if((smallestPossibleBlockSize-sizeNeeded) > (sizeof(metadata_t) + sizeof(int) + sizeof(int) + 1)){
				metadata_t* blockBackOnFreelist;
				metadata_t* blockForUser;
				blockForUser = smallestPossibleBlock;
				blockBackOnFreelist = (metadata_t*)(((char*) smallestPossibleBlock) +(sizeof(metadata_t) + 2*sizeof(int) + size));
				blockBackOnFreelist-> block_size = (smallestPossibleBlockSize - sizeNeeded);
				blockBackOnFreelist-> request_size = 0;
				blockBackOnFreelist-> prev = smallestPossibleBlock->prev;
				blockBackOnFreelist-> next = smallestPossibleBlock->next;
				if((char*)freelist == (char*)blockForUser){				
					freelist = blockBackOnFreelist;
					blockBackOnFreelist->prev = NULL;
					if(blockBackOnFreelist->next != NULL){
						blockBackOnFreelist->next->prev = blockBackOnFreelist;
					}
				}else{
					if(blockBackOnFreelist->prev != NULL){
						blockBackOnFreelist->prev->next = blockBackOnFreelist;
					}
					if(blockBackOnFreelist->next != NULL){
						blockBackOnFreelist->next->prev = blockBackOnFreelist;
					}
				}
				blockForUser-> block_size = sizeNeeded;
				blockForUser-> request_size = size;
				blockForUser-> next = NULL;
				blockForUser-> prev = NULL;
				blockForUser = setCanaries(blockForUser);
				
				return (void*) blockForUser;
			}else{
				metadata_t* blockForUser;
				/*not big enough, give them the whole block
				//set pointers of block on freelist smallestBlock*/
				if(smallestPossibleBlock->prev != NULL){
					smallestPossibleBlock->prev->next = smallestPossibleBlock->next;
				}
				if(smallestPossibleBlock->next != NULL){
					smallestPossibleBlock->next->prev = smallestPossibleBlock->prev;
				}
				if((char*)freelist == (char*) smallestPossibleBlock){
					freelist = smallestPossibleBlock->next;
					smallestPossibleBlock->next = NULL;
				}
				/*give block to user*/
				blockForUser = smallestPossibleBlock;
				blockForUser->block_size = smallestPossibleBlockSize;
				blockForUser->request_size = size;
				blockForUser = setCanaries(blockForUser);
				
				return (void*) blockForUser;
			}
		}
	}
}

/*need to pass beginning of leftblock and rightBlock
//by setting next and prev, I am putting it on free list already*/
metadata_t* merge1(metadata_t* leftBlock, metadata_t* rightBlock){
	/*create a block of double the size out of the buddy's pointer
	//creates big block*/
	/*right block was the one already on the list*/
	leftBlock->block_size = (leftBlock->block_size)+(rightBlock->block_size);
	leftBlock->request_size = 0;
	if((char*)rightBlock != (char*)freelist){
		leftBlock->next = rightBlock->next;
		leftBlock->prev = rightBlock->prev;
		if(leftBlock->next != NULL){
			leftBlock->next->prev = leftBlock;
		}
		if(leftBlock->prev != NULL){
			leftBlock->prev->next = leftBlock;
		}	
	}else{
		leftBlock->next = rightBlock->next;
		leftBlock->prev = NULL;
		freelist = leftBlock;
		if(leftBlock->next != NULL){
			leftBlock->next->prev = leftBlock;
		}
	}
	return leftBlock;
}
/*here rightBLock is an already merged block*/
metadata_t* merge2(metadata_t* leftBlock, metadata_t* rightBlock){
	/*create a block of double the size out of the buddy's pointer
	//creates big block*/


	/*remove rightBLock from list*/
	if((char*)rightBlock == (char*) freelist){
		freelist = rightBlock->next;
		rightBlock->prev = NULL;
	}else{
		/*not the head of the list now remove*/
		rightBlock->prev->next = rightBlock->next;
		if(rightBlock->next != NULL){
			rightBlock->next->prev = rightBlock->prev;
		}
	}
	rightBlock->next = NULL;
	rightBlock->prev = NULL;




	/*then merge it*/
	leftBlock->block_size = (leftBlock->block_size)+(rightBlock->block_size);
	leftBlock->request_size = 0;
        
	return leftBlock;
}
/*here rightblock has never been merged*/
metadata_t* merge3(metadata_t* leftBlock, metadata_t* rightBlock){
	/*create a block of double the size out of the buddy's pointer
	//creates big block*/
	leftBlock->block_size = (leftBlock->block_size)+(rightBlock->block_size);
	leftBlock->request_size = 0;
	return leftBlock;
}


/*go through freelist and check who can merge
//param: handing over right address of original block
//need to check left addresses of blocks on freelist
//return 1 if merged, 0 if not*/
void checkForBuddies(metadata_t* rightAddress, metadata_t* leftAddress){
	metadata_t* curr = freelist;
	char* originalChar = (char*) rightAddress;
	int firstBlockOnFreeList = 1;
	int merged = 0;
	int merged1 = 0;
	while(curr != NULL){
		char* currChar = (char*) curr;
		if(currChar == originalChar){
			/*merge puts blocks together and puts on freelist*/
			leftAddress = merge1(leftAddress,curr);
			merged = 1;
			merged1 = 1;
			if(firstBlockOnFreeList){
				freelist = leftAddress;
			}
		}
		firstBlockOnFreeList = 0;
		curr = curr->next;
	}
	curr = freelist;
	originalChar = (char*) leftAddress;
	while(curr != NULL){
		
		/*get right side of blocks on freelist*/
		char* currChar = ((char*)curr) + curr->block_size;
		if(currChar == originalChar){
			/*merge puts blocks together and puts on freelist*/
			if(merged1){
				leftAddress = merge2(curr,leftAddress);
			}else{
				leftAddress = merge3(curr,leftAddress);
			}
			merged = 1;
		}
		curr = curr->next;
	}
	if(!merged){
		metadata_t* currHead = freelist;
		currHead->prev = leftAddress;
		leftAddress->next = currHead;
		leftAddress->prev = NULL;
		leftAddress->request_size = 0;
		freelist = leftAddress;
	}
}



void my_free(void* ptr)
{
	if(ptr != NULL){
	
		int* firstCanary;
		int* secondCanary;
		metadata_t* leftAddress;
		metadata_t* rightAddress;
		metadata_t* block = (metadata_t*) ptr;
		/*get beginning of block*/
		block = (metadata_t*) (((char*)block) - sizeof(metadata_t) - sizeof(int));
		leftAddress = block;
		/*check canaries*/
		firstCanary = (int*) (((char*)leftAddress) + sizeof(metadata_t));
		if(*firstCanary != CANARY){
			ERRNO = CANARY_CORRUPTED;
		}else{
			secondCanary = (int*)(((char*)leftAddress) + sizeof(metadata_t)+ sizeof(int)+ leftAddress->request_size);
			if(*secondCanary != CANARY){
				ERRNO = CANARY_CORRUPTED;
			}else{
				ERRNO = NO_ERROR;
				rightAddress = (metadata_t*)(((char*)block) + sizeof(metadata_t) + 2*sizeof(int) + block->request_size);
				/*merge blocks*/
				checkForBuddies(rightAddress, leftAddress);
			}
		}
	}
}


