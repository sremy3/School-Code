// bmptoc.c
// Name: Stephanie Remy

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

// This is the array into which you will load the raw data from the file
// You don't have to use this array if you don't want to, but you will be responsible
// for any errors caused by erroneously using the stack or malloc if you do it a
// different way, incorrectly!
char data_arr[0x36 + 240 * 160 * 4];

int main(int argc, char *argv[]) {

	// 1. Make sure the user passed in the correct number of arguments
	if(argc != 2) { 
		//wrong number of arguments
		//exit the program
		printf( "Incorrect number of arguments given. Try again\n" );
	} else if((strlen(argv[1])) > 104) {
		//too many characters in name
		printf( "The name of the file is greater than 100. Try again.\n");
	} else {
		int length = strlen(argv[1]);
		//THIS PART OF THE CODE OPENS THE FILE	
		FILE *infile = fopen(argv[1], "r");
	// 2. Open the file. If it doesn't exist, tell the user and then exit
		if( infile == 0) {
			printf( "Could not open file. Doesn't exist.\n" ); //DOES THIS IF FILE DOES NOT EXIST
		} else {
			// THIS PART OF THE CODE CHANGES EXT TO C AND H
			char cname[104];
			char hname[104];
			strcpy(cname, argv[1]);
			strcpy(hname, argv[1]);
			//change ending to .c and .h 
			cname[length - 2] = 0;
			hname[length - 2] = 0;
			//change b to c
			cname[length - 3] = 99;
			const char *cfile = cname;
			//store it in .cfile filename holder
			hname[length - 3] = 104;
			//change c to h
			const char *hfile = hname;
			//store it in .hfile filename holder

	


	// 3. Read the file into the buffer then close it when you are done
	//read file into the buffer
			fread(data_arr, 1, 160000, infile);			
			//closes the file
			fclose(infile);


	// 4. Get the width and height of the image
	//THIS PART GETS THE WIDTH AND HEIGHT
			unsigned int *width = (unsigned int *) &data_arr[0x12];
			int w = *width;
			unsigned int *height = (unsigned int *) &data_arr[0x16];
			int h = *height;


	// 5. Create header file, and write header contents. Close it
			int picSize = w*h;
			char swidth[120];
			char sheight[120];
			char sdata[120];
			strcpy(swidth, argv[1]);
			strcpy(sheight, argv[1]);
			strcpy(sdata, argv[1]);
			//name is a char array of filename
			//subtract 32 if is lowercase
			int j = 0;
			while (j < (length - 4)) {
				char temp = swidth[j];
				//if lowercase
				if((temp > 96) & (temp < 123)) {
					int inttemp = (int) temp;
					inttemp = inttemp - 32;
					temp = (char) inttemp;
					swidth[j] = temp;
					sheight[j] = temp;
				}
				j++;
			}
			//change ending to width, height, data
			swidth[length + 2] = 0;
			sheight[length + 3] = 0;
			sdata[length + 1] = 0;
			//change to _WIDTH
			swidth[length - 4] = 95;
			swidth[length - 3] = 87;
			swidth[length - 2] = 73;
			swidth[length - 1] = 68;
			swidth[length] = 84;
			swidth[length + 1] = 72;
			const char *something_WIDTH = swidth;

			//change to _HEIGHT
			sheight[length - 4] = 95;
			sheight[length - 3] = 72;
			sheight[length - 2] = 69;
			sheight[length - 1] = 73;
			sheight[length] = 71;
			sheight[length + 1] = 72;
			sheight[length + 2] = 84;
			const char *something_HEIGHT = sheight;
			
			//change to _data
			sdata[length - 4] = 95;
			sdata[length - 3] = 100;
			sdata[length - 2] = 97;
			sdata[length - 1] = 116;
			sdata[length] = 97;
			const char *something_data = sdata;
			
			//create string for hfile
			char header_contents[500];
			sprintf(header_contents, "#define %s %d\n#define %s %d\nconst unsigned short %s[%d];\n", something_WIDTH, w, something_HEIGHT, h, something_data, picSize);
			const char *hc = header_contents;
			
			//create and write string on hfile
			FILE *outfile = fopen(hfile, "w");
			fwrite(hc, 1, (strlen(hc)), outfile);
			fclose(outfile);


	// 6. Create C file, and write pixel data. Close it
			//create c file
			FILE *out = fopen(cfile, "w");
			//write the beginning of file
			char c_contents[200 + (0x36 + 240 * 160 * 4)];
			sprintf(c_contents, "const unsigned short %s[%d] = {", something_data, picSize);
			const char *cc = c_contents;
			fwrite(cc, 1, strlen(cc), out);
			//pointer to front of data_arr
			unsigned int *p = (unsigned int *) &data_arr[0x36];
			for(int i = h -1; i >= 0; i--) {
				for(int j = 0; j < w; j++) {
					//getting pixel with 36 bits
					unsigned int index = p[i*w+j];
					//alter bits
					unsigned short b = (index & 0xFF);
					// CHANGE TO GBA PIX
					b = b >> 3;
					b = b << 10;
					unsigned short g = (index >> 8) & 0xFF; 
					// CHANGE TO GBA PIX
					g = g >> 3;
					g = g << 5;
					
					unsigned short r = (index >> 16) & 0xFF; 
					r = r >> 3;
					unsigned rgb = b | g;
					rgb = rgb | r;
					char shstr[100];
					sprintf(shstr, "%X", rgb);
					fprintf(out, "0x");
					fprintf(out, "%s",shstr);
					if ((j != (w - 1)) | (i != 0)) {
						fprintf(out, ", \n");
					}
				}
			}

			
			
			
			
			//add }; to end of string
			char ending[200 + (0x36 + 240 * 160 * 4)];
			sprintf(ending, "};");
			const char *end = ending;
			fwrite(end, 1, strlen(end), out);
			
			
			
			//close file
			fclose(out);

		}
	}
}

