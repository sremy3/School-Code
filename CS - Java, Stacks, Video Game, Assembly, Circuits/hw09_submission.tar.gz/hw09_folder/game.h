/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 game game.png 
 * Time-stamp: Thursday 04/02/2015, 11:43:28
 * 
 * Image Information
 * -----------------
 * game.png 220@137
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef GAME_H
#define GAME_H

extern const unsigned short game[30140];
#define GAME_SIZE 30140
#define GAME_WIDTH 220
#define GAME_HEIGHT 137

#endif

