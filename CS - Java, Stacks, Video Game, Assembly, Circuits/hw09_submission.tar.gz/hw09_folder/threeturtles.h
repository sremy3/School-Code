/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 threeturtles threeturtles.png 
 * Time-stamp: Tuesday 03/31/2015, 19:16:12
 * 
 * Image Information
 * -----------------
 * threeturtles.png 45@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef THREETURTLES_H
#define THREETURTLES_H

extern const unsigned short threeturtles[675];
#define THREETURTLES_SIZE 675
#define THREETURTLES_WIDTH 45
#define THREETURTLES_HEIGHT 15

#endif

