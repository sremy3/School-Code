/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 lilypad lilypad.png 
 * Time-stamp: Wednesday 04/01/2015, 05:37:31
 * 
 * Image Information
 * -----------------
 * lilypad.png 17@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef LILYPAD_H
#define LILYPAD_H

extern const unsigned short lilypad[255];
#define LILYPAD_SIZE 255
#define LILYPAD_WIDTH 17
#define LILYPAD_HEIGHT 15

#endif

