/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 medlog medlog.png 
 * Time-stamp: Wednesday 04/01/2015, 05:43:58
 * 
 * Image Information
 * -----------------
 * medlog.png 54@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef MEDLOG_H
#define MEDLOG_H

extern const unsigned short medlog[810];
#define MEDLOG_SIZE 810
#define MEDLOG_WIDTH 54
#define MEDLOG_HEIGHT 15

#endif

