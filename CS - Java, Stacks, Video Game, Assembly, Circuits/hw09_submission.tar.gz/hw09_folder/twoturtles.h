/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 twoturtles twoturtles.png 
 * Time-stamp: Wednesday 04/01/2015, 00:20:36
 * 
 * Image Information
 * -----------------
 * twoturtles.png 30@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef TWOTURTLES_H
#define TWOTURTLES_H

extern const unsigned short twoturtles[450];
#define TWOTURTLES_SIZE 450
#define TWOTURTLES_WIDTH 30
#define TWOTURTLES_HEIGHT 15

#endif

