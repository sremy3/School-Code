/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 c /home/sremy3/Downloads/nin10kit-master/c.png 
 * Time-stamp: Tuesday 03/31/2015, 10:26:20
 * 
 * Image Information
 * -----------------
 * /home/sremy3/Downloads/nin10kit-master/c.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef C_H
#define C_H

extern const unsigned short c[38400];
#define C_SIZE 38400
#define C_WIDTH 240
#define C_HEIGHT 160

#endif

