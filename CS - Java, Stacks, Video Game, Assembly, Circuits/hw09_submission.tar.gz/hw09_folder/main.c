////STEPHANIE REMY////

//IMPORT FILES
#include "game.h"
#include "b.h"
#include "c.h"
#include "myLib.h"
#include "text.h"
#include "medlog.h"
#include "lilypad.h"
#include "longlog.h"
#include "smalllog.h"
#include "twoturtles.h"
#include "threeturtles.h"
#include "frog.h"
#include "blackblock.h"
#include "homefrog.h"
#include "death.h"
#include <stdio.h>


//GLOBAL VARIABLES
enum {SPLASH, GAME, GAMEOVER};
char buffer[41];
int score = 0;

//MAIN FUNCTION
int main(){
        REG_DISPCTL = MODE3 | BG2_ENABLE;
	int state = SPLASH;
	int whichOne = 0;
	while(1) {
		switch (state){
		    //TITLE PAGE
		    case SPLASH:
		        title();
		        state = GAME;
		        break;
		    //ACTUAL GAME
		    case GAME:
			whichOne = theGame();
			if(whichOne==1) {
				state = GAMEOVER;
			}else{
				state = SPLASH;
			}
		        break;
		    //GAMEOVER PAGE
		    case GAMEOVER:
		        gameOver();
		        state = SPLASH;
		        break;
		}		
	}
}
//TITLE PAGE
void title() {
	DMA[3].src = c;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = (240*160) | DMA_ON;
	//RESET SCORE
	score = 0;
	while(!KEY_DOWN_NOW(BUTTON_START));
}
//GAMEOVER PAGE
void gameOver(){
	DMA[3].src = b;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = (240*160) | DMA_ON;
	sprintf(buffer, "Score: %d", score);
	drawString(90, 90, buffer, YELLOW);
	while(!KEY_DOWN_NOW(BUTTON_SELECT));
	score = 0;
}
//THE ACTUAL GAME
int theGame(){
	
	waitForVblank();

	//CREATE ROWS OF MOVING 
	OBJECT firstRow[1];
	OBJECT* current;
	OBJECT secondRow[1];
	OBJECT* currentS;
	OBJECT thirdRow[1];
	OBJECT* currentT;
	OBJECT fourthRow[1];
	OBJECT* currentF;
	OBJECT fifthRow[1];
	OBJECT* currentFi;
	//CREATE TOP ROW
	int i;
	int crr;
	firstRow[0].cr = 47;
	firstRow[0].cc = 20;
	firstRow[0].width = 45;
	firstRow[0].height = 15;
	firstRow[0].image = threeturtles;
	//CREATE SECOND ROW
	for(i=0, crr = 30; i < 1; i++) {
		secondRow[i].cr = 62;
		secondRow[i].cc = crr;
		secondRow[i].width = 54;
		secondRow[i].height = 15;
		secondRow[i].image = medlog;
		crr = crr + 90;
	}
	//CREATE THIRD ROW
	for(i=0, crr = 40; i < 1; i++) {
		thirdRow[i].cr = 77;
		thirdRow[i].cc = crr;
		thirdRow[i].width = 30;
		thirdRow[i].height = 15;
		thirdRow[i].image = twoturtles;
		crr = crr + 87;
	}
	//CREATE FOURTH ROW
	for(i=0, crr = 30; i < 1; i++) {
		fourthRow[i].cr = 92;
		fourthRow[i].cc = crr;
		fourthRow[i].width = 41;
		fourthRow[i].height = 15;
		fourthRow[i].image = smalllog;
		crr = crr + 65;
	}
	//CREATE FIFTH ROW
	for(i=0, crr = 20; i < 1; i++) {
		fifthRow[i].cr = 107;
		fifthRow[i].cc = crr;
		fifthRow[i].width = 64;
		fifthRow[i].height = 15;
		fifthRow[i].image = longlog;
	}
	//CREATE VARIOUS VARIABLES
	int keepGoing = 1;
	u16 bgcolor = BLACK;
	int row = 20;
	int col = 10;
	int pl[] = {17, 64, 110, 159, 205};
	int x;
	int cd = 1;
	int cdd = -1;
	int cf = 1;
	int cff = -1;
	int cfff = 1;
	int endgame = 1;
	int lives = 2;
	//CREATE BLACK BACKGROUND
	DMA[3].src = &bgcolor;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = (240*160) | DMA_SOURCE_FIXED | DMA_ON;
	//DRAW GAME
	drawImage3(row, col, 220, 137, game);
	//CREATE SCORE MARKER
	sprintf(buffer, "Score: %d", score);
	drawString(145, 112, buffer, YELLOW);
	//CREATE LILYPADS
	LILY theLily[5];
	LILY* lilypads;
	for(x=0; x<5;x++){
		theLily[x].cr = 28;
		theLily[x].cc = pl[x];
		theLily[x].width = 17;
		theLily[x].height = 15;
		theLily[x].image = lilypad;
		theLily[x].alreadyTaken = 0;
		drawImage3(28, pl[x], 17, 15, lilypad);
	}
	//CREATE LIVES MARKER
	sprintf(buffer, "Lives: %d", (lives + 1));
	drawString(145, 17, buffer, YELLOW);
	//CREATE FROG OBJECT
	OBJECT theFrog[1];
	OBJECT* frogPtr;
	theFrog[0].cr = 122;
	theFrog[0].cc = 115;
	theFrog[0].width = 15;
	theFrog[0].height = 15;
	theFrog[0].image = frog;
	frogPtr = &theFrog[0];
	//DRAW FROG
	drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
	int oldCr = frogPtr->cr;
	int oldCc = frogPtr->cc;
	//FINISHED SETTING UP BOARD, GAME ACTUALLY BEGINS
	waitForVblank();
	int movementCooldown = 0;
	while(keepGoing > 0){
		//BUTTON UP FUNCTIONS
		if(KEY_DOWN_NOW(BUTTON_UP) && !movementCooldown){
			score = score + 10;
			sprintf(buffer, "Score: %d", score);
			drawImage3(145, 147, 50, 16, blackblock);
			drawString(145, 112, buffer, YELLOW);
			oldCr = frogPtr->cr;
			oldCc = frogPtr->cc;
			frogPtr->cr = frogPtr->cr - 15;
			if((45>=oldCr) || (oldCr>=122)) {
				draw_image_portion(oldCr, oldCc, oldCr-20, oldCc-10, frogPtr->width, frogPtr->height, game, 220);
			}
			//MOVE FROG UP
			drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
			movementCooldown = 50;
		}
		//BUTTON DOWN FUNCTIONS
		if(KEY_DOWN_NOW(BUTTON_DOWN) && !movementCooldown){
			score = score - 10;
			sprintf(buffer, "Score: %d", score);
			oldCr = frogPtr->cr;
			oldCc = frogPtr->cc;
			drawImage3(145, 147, 50, 16, blackblock);
			waitForVblank();
			drawString(145, 112, buffer, YELLOW);
			if((frogPtr->cr + 15) == 137){
				//IF FROG JUMPS OFFSCREEN, HE DIES
				if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						//IF HAS LIVES LEFT TAKE AWAY LIFE AND RESET PIECE
						lives--;
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
			} else{
				//FROG MADE IT FORWARD AND MOVES
				frogPtr->cr = frogPtr->cr + 15;
				if((45>=oldCr) || (oldCr>=122)) {
					draw_image_portion(oldCr, oldCc, oldCr-20, oldCc-10, frogPtr->width, frogPtr->height, game, 220);
				}
				//MOVE FROG DOWN
				drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
			}
			movementCooldown = 50;
		}
		if(KEY_DOWN_NOW(BUTTON_LEFT) && !movementCooldown){
			oldCr = frogPtr->cr;
			oldCc = frogPtr->cc;
			if((frogPtr->cc) <= 11){
				//IF FROG JUMPS OFFSCREEN, HE DIES
				if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						//IF HAS LIVES LEFT TAKE AWAY LIFE AND RESET PIECE
						lives--;
						waitForVblank();
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
			} else{
				draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
				frogPtr->cc = frogPtr->cc - 15;
				waitForVblank();
				
				drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
			}
			movementCooldown = 50;
		}
		if(KEY_DOWN_NOW(BUTTON_RIGHT) && !movementCooldown){
			oldCr = frogPtr->cr;
			oldCc = frogPtr->cc;
			if((frogPtr->cc + 15) >= 230){
				//IF FROG JUMPS OFFSCREEN, HE DIES
				if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						//IF HAS LIVES LEFT TAKE AWAY LIFE AND RESET PIECE
						lives--;
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
			} else{
				draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
				frogPtr->cc = frogPtr->cc + 15;
				waitForVblank();
				
				drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
			}
			movementCooldown = 50;
		}
		if(movementCooldown > 0){
			movementCooldown--;
		}
		int frogC = frogPtr->cc;
		int frogR = frogPtr->cr;
	//CHECK IF HITTING A LILYPAD Lilypads
		if(frogR <= 43) {
			int f;
			int missed = 0;
			lilypads = &theLily[0];
			int check = 0;
			for(f=0;f<5;f++){
				int lc = lilypads->cc;
				int taken = lilypads->alreadyTaken;
				if(taken > 0) {
					check++;
				}
				if(((lc-10) <=frogC)&&((lc+10)>=frogC)){
					
					if(taken < 1){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					drawImage3(lilypads->cr, lilypads->cc, 17, 15, homefrog);
					lilypads->alreadyTaken = 1;		
					drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					frogPtr->cr = 122;
					frogPtr->cc = 115;
					missed = 1;
					check++;
					}
				}
				lilypads++;
			}
			if(missed <1){
				//IF FROG DIES
				if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
			}
			//CHECK IF WON GAME
			if(check > 4){
				
				sprintf(buffer, "You Won!!!");
				drawImage3(75, 60, 120, 16, blackblock);
				waitForVblank();
				drawString(78, 90, buffer, RED);
				delay(1);
				endgame = 0;
				keepGoing = 0;
			}
		}
		waitForVblank();
		int j;
		//DRAW FIRST ROW
		for(j=0; j<1;j++){
			current = &firstRow[j];
			int getCC = current->cc;
			
			
			if((getCC + 45) == 230){
				cd = -1;
			}
			if(getCC == 11){
				cd = 1;	
			}
			
			current->cc = (current->cc) + cd;		
			drawImage3(current->cr, current->cc, current->width, current->height, current->image);
			//if frog hit the log go with it
			//check if right row
			if((frogR > (45))&&(frogR<59)){
				
				if((frogC>(getCC-2))&&(frogC<((getCC + 45)+2))){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					frogPtr->cc = (frogPtr->cc) + cd;
					drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
				} else {
					if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
				}
			}
		}
		//DRAW THIRD ROW
		for(j=0; j<1;j++){
			currentT = &thirdRow[j];
			int getCC = currentT->cc;
			if((getCC + 30) == 230){
				cf = -1;
			}
			if(getCC == 11){
				cf = 1;	
			}
			currentT->cc = (currentT->cc) + cf;	
			drawImage3(currentT->cr, currentT->cc, currentT->width, currentT->height, currentT->image);
			//if frog hit the log go with it
			//check if right row
			if((frogR > (75))&&(frogR<84)){
				
				if((frogC>(getCC-2))&&(frogC<((getCC + 30)+2))){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					frogPtr->cc = (frogPtr->cc) + cf;
					drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
				} else {
					if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
				}
			}
		}
		for(j=0; j<1;j++){
			currentF = &fourthRow[j];
			int getCC = currentF->cc;
			if((getCC + 41) == 230){
				cff = -1;
			}
			if(getCC == 11){
				cff = 1;	
			}
			currentF->cc = (currentF->cc) + cff;		
			drawImage3(currentF->cr, currentF->cc, currentF->width, currentF->height, currentF->image);
			//if frog hit the log go with it
			//check if right row
			if((frogR > (85))&&(frogR<100)){
				
				if((frogC>(getCC-2))&&(frogC<((getCC + 41)+2))){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					frogPtr->cc = (frogPtr->cc) + cff;
					drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
				} else {
					if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
				}
			}
		}
		//create fifthrow
		for(j=0; j<1;j++){
			currentFi = &fifthRow[j];
			int getCC = currentFi->cc;
			if((getCC + 64) == 230){
				cfff = -1;
			}
			if(getCC <= 11){
				cfff = 1;	
			}
			
			currentFi->cc = (currentFi->cc) + cfff;
			drawImage3(currentFi->cr, currentFi->cc, currentFi->width, currentFi->height, currentFi->image);
			//if frog hit the log go with it
			//check if right row
			if((frogR > (105))&&(frogR<122)){
				
				if((frogC>(getCC -2))&&(frogC<((getCC + 45)+2))){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					frogPtr->cc = (frogPtr->cc) + cfff;
					drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
				} else {
					if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
				}
			}
		}
		//DRAW SECOND ROW
		for(j=0; j<1;j++){
			currentS = &secondRow[j];
			int getCC = currentS->cc;
			if((getCC + 54) == 230){
				cdd = -1;
			}
			if(getCC == 11){
				cdd = 1;	
			}
			currentS->cc = (currentS->cc) + cdd;	
			drawImage3(currentS->cr, currentS->cc, currentS->width, currentS->height, medlog);
			//if frog hit the log go with it
			//check if right row
			if((frogR > (60))&&(frogR<72)){
				
				if((frogC>(getCC-2))&&(frogC<((getCC + 54)+2))){
					draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
					frogPtr->cc = (frogPtr->cc) + cdd;
					drawImage3(frogPtr->cr, frogPtr->cc, frogPtr->width, frogPtr->height, frogPtr->image);
				} else {
					if(lives == 0){
						endgame = 0;
						keepGoing = 0;
					}else{
						lives--;
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, frogPtr->width, frogPtr->height, game, 220);		
						drawImage3(frogPtr->cr, frogPtr->cc, 16, 16, death);
						drawImage3(145, 20, 50, 16, blackblock);
						sprintf(buffer, "Lives: %d", (lives + 1));
						waitForVblank();
						drawString(145, 17, buffer, YELLOW);
						delay(1);
						waitForVblank();
						draw_image_portion(frogPtr->cr, frogPtr->cc, frogPtr->cr-20, frogPtr->cc-10, 16, 16, game, 220);		
						frogPtr->cr = 122;
						frogPtr->cc = 115;
						drawImage3(122, 115, frogPtr->width, frogPtr->height, frogPtr->image);
					}
				}
			}
		}
		
		if((KEY_DOWN_NOW(BUTTON_SELECT))|(KEY_DOWN_NOW(BUTTON_A))){ keepGoing = 0; 
}
		
		}
		while((!KEY_DOWN_NOW(BUTTON_SELECT))&&(endgame > 0));
		if(KEY_DOWN_NOW(BUTTON_SELECT)){
			return 0;
		}
		if(endgame == 0){
			return 1;
		}
		return 1;
}

