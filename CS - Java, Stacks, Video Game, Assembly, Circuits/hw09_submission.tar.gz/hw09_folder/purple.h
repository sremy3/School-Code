/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 purple purple.png 
 * Time-stamp: Wednesday 04/01/2015, 05:45:52
 * 
 * Image Information
 * -----------------
 * purple.png 15@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef PURPLE_H
#define PURPLE_H

extern const unsigned short purple[225];
#define PURPLE_SIZE 225
#define PURPLE_WIDTH 15
#define PURPLE_HEIGHT 15

#endif

