/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 death death.gif 
 * Time-stamp: Wednesday 04/01/2015, 05:36:47
 * 
 * Image Information
 * -----------------
 * death.gif 16@16
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef DEATH_H
#define DEATH_H

extern const unsigned short death[256];
#define DEATH_SIZE 256
#define DEATH_WIDTH 16
#define DEATH_HEIGHT 16

#endif

