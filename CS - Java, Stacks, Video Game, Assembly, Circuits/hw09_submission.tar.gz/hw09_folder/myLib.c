////STEPHANIE REMY////

#include "myLib.h"

//BUFFER
u16 *videoBuffer = (u16*) 0x6000000;


//HELPER DRAW METHODS
void setPixel(int r, int c, u16 color) {
	videoBuffer[OFFSET(r, c, 240)] = color;
}

void draw_image_portion(int destination_row, int destination_col, int source_row, int source_col, int source_width, int source_height, const u16* image, int image_width){	
    int row;
    for(row=0; row<(source_height); row++)
    {
	DMA[3].src = (image +(image_width*(source_row+row)+source_col));
        DMA[3].dst = (videoBuffer + (240*(destination_row+row)+destination_col));
        DMA[3].cnt = (source_width) | DMA_ON;
    }

}
void drawImage3(int r, int c, int width, int height, const u16* image) {
    int row;
    for(row=0; row<height; row++)
    {
	
	DMA[3].src = image +(width*row);
        DMA[3].dst = (videoBuffer + (240*(r+row)+c));
        DMA[3].cnt = (width) | DMA_ON;
    }
}
void waitForVblank(){
    while(SCANLINECOUNTER > 160);
    while(SCANLINECOUNTER < 160);
}
void delay(int n){
    int i = 0;
    volatile int x=0;
    for(i=0; i<n*100000; i++)
    {
        x++;
    }
}
