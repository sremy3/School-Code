/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 longlog longlog.png 
 * Time-stamp: Wednesday 04/01/2015, 05:37:41
 * 
 * Image Information
 * -----------------
 * longlog.png 64@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef LONGLOG_H
#define LONGLOG_H

extern const unsigned short longlog[960];
#define LONGLOG_SIZE 960
#define LONGLOG_WIDTH 64
#define LONGLOG_HEIGHT 15

#endif

