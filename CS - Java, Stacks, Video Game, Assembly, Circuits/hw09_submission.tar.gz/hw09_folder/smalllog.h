/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 smalllog smalllog.png 
 * Time-stamp: Wednesday 04/01/2015, 05:38:41
 * 
 * Image Information
 * -----------------
 * smalllog.png 41@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef SMALLLOG_H
#define SMALLLOG_H

extern const unsigned short smalllog[615];
#define SMALLLOG_SIZE 615
#define SMALLLOG_WIDTH 41
#define SMALLLOG_HEIGHT 15

#endif

