/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 homefrog homefrog.png 
 * Time-stamp: Wednesday 04/01/2015, 05:37:07
 * 
 * Image Information
 * -----------------
 * homefrog.png 17@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef HOMEFROG_H
#define HOMEFROG_H

extern const unsigned short homefrog[255];
#define HOMEFROG_SIZE 255
#define HOMEFROG_WIDTH 17
#define HOMEFROG_HEIGHT 15

#endif

