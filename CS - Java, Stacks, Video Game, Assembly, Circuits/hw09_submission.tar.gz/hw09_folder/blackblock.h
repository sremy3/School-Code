/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 blackblock blackblock.png 
 * Time-stamp: Thursday 04/02/2015, 17:40:02
 * 
 * Image Information
 * -----------------
 * blackblock.png 50@16
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef BLACKBLOCK_H
#define BLACKBLOCK_H

extern const unsigned short blackblock[800];
#define BLACKBLOCK_SIZE 800
#define BLACKBLOCK_WIDTH 50
#define BLACKBLOCK_HEIGHT 16

#endif

