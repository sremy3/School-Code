/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 frog frog.gif 
 * Time-stamp: Wednesday 04/01/2015, 05:36:38
 * 
 * Image Information
 * -----------------
 * frog.gif 15@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef FROG_H
#define FROG_H

extern const unsigned short frog[225];
#define FROG_SIZE 225
#define FROG_WIDTH 15
#define FROG_HEIGHT 15

#endif

