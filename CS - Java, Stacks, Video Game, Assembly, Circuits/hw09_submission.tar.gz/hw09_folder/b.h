/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 b /home/sremy3/Downloads/nin10kit-master/20368.gif.jpg 
 * Time-stamp: Tuesday 03/31/2015, 10:27:05
 * 
 * Image Information
 * -----------------
 * /home/sremy3/Downloads/nin10kit-master/20368.gif.jpg 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef B_H
#define B_H

extern const unsigned short b[38400];
#define B_SIZE 38400
#define B_WIDTH 240
#define B_HEIGHT 160

#endif

