/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 blueblock blueblock.png 
 * Time-stamp: Wednesday 04/01/2015, 10:30:08
 * 
 * Image Information
 * -----------------
 * blueblock.png 15@15
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef BLUEBLOCK_H
#define BLUEBLOCK_H

extern const unsigned short blueblock[225];
#define BLUEBLOCK_SIZE 225
#define BLUEBLOCK_WIDTH 15
#define BLUEBLOCK_HEIGHT 15

#endif

