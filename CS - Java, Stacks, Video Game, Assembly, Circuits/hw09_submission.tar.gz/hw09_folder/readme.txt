**STEPHANIE REMY***
---Explanation of the Game---

The game that is implemented is called Frogger. The frog is trying to move across the lake to the lilly pads without falling into the water or without hitting the turtles. Multiple frogs cannot occupy the same lilly pad. The player is only given three lives to complete the level. The game is won if all frogs get to the lilly pads.

---Controls--- 
Start Game - Enter
Restart Game- Backspace
Move up- Up Arrow
Move down- Down Arrow
Move left- Left Arrow
Move right- Right Arrow
